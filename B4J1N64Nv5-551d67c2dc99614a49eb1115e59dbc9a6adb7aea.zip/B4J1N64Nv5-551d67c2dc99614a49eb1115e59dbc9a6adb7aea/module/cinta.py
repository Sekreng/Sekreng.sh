qty=int(input("Berapa Persen Cintamu ke aku?"))
jumlah=qty
if jumlah > 100 :
    keterangan="kamu sangat mencintai aku, Kamu mau gk jadi pendamping hidup aku?"
elif jumlah > 75 and jumlah <= 100:
	keterangan="Kamu cinta sama aku, kamu mau gk jadi pendamping hidup aku?"
elif jumlah > 46 and jumlah <= 75:
	keterangan="kamu sederhana dalam mencintai, kamu mau gk jadi pendamping hidup aku?"
elif jumlah > 20 and jumlah <= 46:
	keterangan="kamu benci aku, tolong jangan benci sama aku"
elif jumlah > 0 and jumlah <= 20:
	keterangan="kamu sangat benci aku, :'-("
print ("Jumlah=", jumlah)
print ("Keterangan=", keterangan)
print ("========================")
print ("JANGAN MERINDUKAN AKU,BERAT!!! KAMU GK BAKAL KUAT, BIAR AKU AJAH :v ")
print ("========================")
print ("by.MR.B4J1N64N")
print ("========================")
print ("     #        #            ############   #             #      #######          #        #    #########    #        #            # # #  # # # # ")  
print ("     #        #            #          #    #           #       #                 #      #     #       #    #        #          #      ##        # ")
print ("     #        #            #          #     #         #        #                  #    #      #       #    #        #          #                # ")
print ("     #        #            #          #      #       #         #                   #  #       #       #    #        #           #              # ")
print ("     #        #            #          #       #     #          #######              ##        #       #    #        #             #          # ")
print ("     #        #            #          #        #   #           #                    ##        #       #    #        #               #      # ")
print ("     #        #            #          #         # #            #                    ##        #       #    #        #                 #  # ") 
print ("     #        ########     ############          #             #######              ##        #########     ########                   ## ")
print ("========================") 
print ("SAVE PROGRAMER GALAU")
print ("")

pio=int(input("tekan enter untuk mematikan"))
